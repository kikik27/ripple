# Ripple Opening Kit v1.0
**Small Actions. Big Impact.**

This is an additive opening cinematic patch for Ripple Complete Development Kit v1.1, not a replacement game. Extract into the same repo; included copies of runtime sprites and hub audio are unchanged. New files are confined to cinematic assets, hub fixture, opening adapter, docs and examples. Keep the previous asset manifest and gameplay fixtures; register these new cinematic resources in your app separately (they are not part of the original atlas).

- Video: `apps/web/public/assets/cinematic/ripple_opening.mp4`
- Exact scene composition: `apps/web/public/assets/cinematic/opening_last_frame.png`
- Game start scene: `fixtures/himalayan-haven-intro.json` and runtime `haven-scene.json`
- Demo: open `examples/opening-demo.html` after extracting, or use the standalone HTML distributed separately. If a browser restricts local resources, serve the folder locally with `python -m http.server 8000` and open `/examples/opening-demo.html`.
- Integration: `integration/opening-transition.ts` (example, not compiled against a production project), `docs/OPENING_HANDOFF.md` (normative scene contract and QA).

The demo implements only the hub and opening handoff, not the complete adventure. The cinematic is a sprite-based animatic using existing art, procedural mountain/cave backgrounds, and original audio from Ripple Audio Pack v2. Lofi IP and Ripple name remain provisional pending permissions, as in the original kit.
