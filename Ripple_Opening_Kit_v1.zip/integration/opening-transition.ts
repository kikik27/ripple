/** Framework-neutral DOM adapter. Call from the New Game user gesture.
 * Preload the actual Haven scene BEFORE playback. onEnter must reveal the already
 * rendered game scene using haven-scene.json and then enable controls.
 * This sample is not wired to a production Phaser app yet. */
export function playRippleOpening(opts: {
  stage: HTMLElement; onEnter: (reason: 'ended' | 'skip' | 'error') => void;
  muted?: boolean; videoUrl?: string;
}) {
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {position:'absolute', inset:'0', zIndex:'50', background:'#142C40'});
  const video = document.createElement('video');
  video.src = opts.videoUrl ?? '/assets/cinematic/ripple_opening.mp4';
  video.playsInline = true; video.preload = 'auto'; video.muted = opts.muted ?? false;
  Object.assign(video.style,{width:'100%',height:'100%',objectFit:'contain',display:'block'});
  const skip = document.createElement('button');
  skip.textContent = 'Skip intro'; skip.type = 'button';
  Object.assign(skip.style,{position:'absolute',right:'12px',top:'12px',zIndex:'1'});
  let finished = false;
  function onKey(e: KeyboardEvent) { if(e.key==='Escape') finish('skip'); }
  function finish(reason: 'ended' | 'skip' | 'error') {
    if (finished) return; finished=true;
    video.pause(); window.removeEventListener('keydown',onKey);
    // Keep the overlay until the pre-rendered scene is ready to reveal.
    try { opts.onEnter(reason); } finally { overlay.remove(); }
  }
  skip.onclick=()=>finish('skip'); video.onended=()=>finish('ended'); video.onerror=()=>finish('error');
  overlay.append(video,skip); opts.stage.append(overlay);
  window.addEventListener('keydown',onKey);
  video.play().catch(()=>finish('error'));
  return { skip:()=>finish('skip'), dispose:()=>{finished=true;video.pause();window.removeEventListener('keydown',onKey);overlay.remove();} };
}
